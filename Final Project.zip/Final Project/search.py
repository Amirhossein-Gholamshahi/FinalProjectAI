# search.py
# ---------
# Licensing Information:  You are free to use or extend these projects for
# educational purposes provided that (1) you do not distribute or publish
# solutions, (2) you retain this notice, and (3) you provide clear
# attribution to UC Berkeley, including a link to http://ai.berkeley.edu.
# 
# Attribution Information: The Pacman AI projects were developed at UC Berkeley.
# The core projects and autograders were primarily created by John DeNero
# (denero@cs.berkeley.edu) and Dan Klein (klein@cs.berkeley.edu).
# Student side autograding was added by Brad Miller, Nick Hay, and
# Pieter Abbeel (pabbeel@cs.berkeley.edu).


"""
In search.py, you will implement generic search algorithms which are called by
Pacman agents (in searchAgents.py).
"""

import util

class SearchProblem:
    """
    This class outlines the structure of a search problem, but doesn't implement
    any of the methods (in object-oriented terminology: an abstract class).

    You do not need to change anything in this class, ever.
    """

    def getStartState(self):
        """
        Returns the start state for the search problem.
        """
        util.raiseNotDefined()

    def isGoalState(self, state):
        """
          state: Search state

        Returns True if and only if the state is a valid goal state.
        """
        util.raiseNotDefined()

    def expand(self, state):
        """
          state: Search state

        For a given state, this should return a list of triples, (child,
        action, stepCost), where 'child' is a child to the current
        state, 'action' is the action required to get there, and 'stepCost' is
        the incremental cost of expanding to that child.
        """
        util.raiseNotDefined()

    def getActions(self, state):
        """
          state: Search state

        For a given state, this should return a list of possible actions.
        """
        util.raiseNotDefined()

    def getActionCost(self, state, action, next_state):
        """
          state: Search state
          action: action taken at state.
          next_state: next Search state after taking action.

        For a given state, this should return the cost of the (s, a, s') transition.
        """
        util.raiseNotDefined()

    def getNextState(self, state, action):
        """
          state: Search state
          action: action taken at state

        For a given state, this should return the next state after taking action from state.
        """
        util.raiseNotDefined()

    def getCostOfActionSequence(self, actions):
        """
         actions: A list of actions to take

        This method returns the total cost of a particular sequence of actions.
        The sequence must be composed of legal moves.
        """
        util.raiseNotDefined()


def tinyMazeSearch(problem):
    """
    Returns a sequence of moves that solves tinyMaze.  For any other maze, the
    sequence of moves will be incorrect, so only use this for tinyMaze.
    """
    from game import Directions
    s = Directions.SOUTH
    w = Directions.WEST
    return  [s, s, w, s, w, w, s, w]


def depthFirstSearch(problem):
    """
    Search the deepest nodes in the search tree first.

    Your search algorithm needs to return a list of actions that reaches the
    goal. Make sure to implement a graph search algorithm.

    To get started, you might want to try some of these simple commands to
    understand the search problem that is being passed in:

    print("Start:", problem.getStartState())
    print("Is the start a goal?", problem.isGoalState(problem.getStartState()))
    """
    "*** YOUR CODE HERE ***"
    frontier = util.Stack() # in DFS frontier is a STACK

    startNode = (problem.getStartState(), 0, [])  # start contains node, cost, and path

    frontier.push(startNode)

    expanded = set() # explored (sometimes called visited) is a set that contains every node that is already expanded or visited

    while not (frontier.isEmpty()):

        (node, cost, path) = frontier.pop() # popping the last pushed element(LIFO/Last In First Out) and then expanding it

        if problem.isGoalState(node):
            return path

        if not (node in expanded):

            expanded.add(node)

            for next_node, next_action, next_cost in problem.expand(node):
                totalCost = cost + next_cost

                totalPath = path + [next_action]

                totalState = (next_node, totalCost, totalPath)

                frontier.push(totalState)

    util.raiseNotDefined()



def breadthFirstSearch(problem):
    """Search the shallowest nodes in the search tree first."""
    "*** YOUR CODE HERE ***"
    frontier = util.Queue() # in BFS frontier is a QUEUE

    startNode = (problem.getStartState(), 0, [])  # start contains node, cost, and path

    frontier.push(startNode)

    expanded = set() # explored (sometimes called visited) is a set that contains every node that is already expanded or visited

    while not (frontier.isEmpty()):

        (node, cost, path) = frontier.pop() # popping the first pushed node(FIFO/First In First Out) and then expanding it

        if problem.isGoalState(node):
            return path

        if not (node in expanded):

            expanded.add(node)

            for next_node, next_action, next_cost in problem.expand(node):
                totalCost = cost + next_cost

                totalPath = path + [next_action]

                totalState = (next_node, totalCost, totalPath)

                frontier.push(totalState)
    util.raiseNotDefined()

def nullHeuristic(state, problem=None):
    """
    A heuristic function estimates the cost from the current state to the nearest
    goal in the provided SearchProblem.  This heuristic is trivial.
    """
    return 0
import heapq
def aStarSearch(problem, heuristic=nullHeuristic):# this partion of the code works for a star algorithm but it can also work for UCS with some minor modifications because we know that UCS is an A star with nullHeuristic  
    """Search the node that has the lowest combined cost and heuristic first."""
    "*** YOUR CODE HERE ***"

    def update_frontier(frontier, item, f_cost): # this function is the same as the function in util and is used for updating the PriorityQueue
        for index, (p, c, i) in enumerate(frontier.heap):
            if i[0] == item[0]:
                if p <= f_cost:
                    break
                del frontier.heap[index]
                frontier.heap.append((f_cost, c, item))
                heapq.heapify(frontier.heap)
                break
        else:
            frontier.push(item, f_cost)

    explored = set() # explored (sometimes called visited) is a set that contains every node that is already expanded or visited

    frontier = util.PriorityQueue()


    frontier.push((problem.getStartState(), []), heuristic(problem.getStartState(), problem)) # g_cost of start node is zero ---> f_cost = h_cost


    explored.add(problem.getStartState())


    while not frontier.isEmpty():

        node, actions = frontier.pop()


        if problem.isGoalState(node):

            return actions

        if node not in explored:
            explored.add(node)

        for every_expanded_node in problem.expand(node):

            next_node = every_expanded_node[0]

            action = every_expanded_node[1]

            totalPath = actions + [action] # path from start till now

            g_cost = problem.getCostOfActionSequence(totalPath) # cost of actions from start till now

            h_cost = heuristic(next_node, problem) # estimate cost of minimum path from current node to goalstate

            f_cost = g_cost + h_cost # evaluation function used for prioritizing nodes in the frontier

            if next_node not in explored:

                update_frontier(frontier, (next_node, totalPath), f_cost)

    util.raiseNotDefined()


# Abbreviations
bfs = breadthFirstSearch
dfs = depthFirstSearch
astar = aStarSearch
